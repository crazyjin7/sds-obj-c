//
//  Engine.m
//  CarParts
//
//  Created by LingoStar on 10. 05. 24.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Engine.h"
#import "Car.h"

@implementation Engine


- (NSString *)description
{
	return @"I am an engine, Vroom";
}

@end
