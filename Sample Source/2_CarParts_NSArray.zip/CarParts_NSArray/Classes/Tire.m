//
//  Tire.m
//  CarParts
//
//  Created by LingoStar on 10. 05. 24.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Tire.h"


@implementation Tire

- (NSString *)description
{
	return @"I am a tire, I last a while";
}
@end
